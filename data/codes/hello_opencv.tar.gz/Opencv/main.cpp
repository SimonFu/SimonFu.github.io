#include <QCoreApplication>
#include <QDebug>

#include "opencv2/opencv.hpp"

using namespace cv;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Mat img = cv::imread(argv[1]);
    if(img.empty())
    {
        return 0;
    }

    imshow("实例图片", img);

    return a.exec();
}
